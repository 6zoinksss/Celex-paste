#pragma once
/* =============================================================
/*                       theo's offsets                         
/*                  https://offsets.imtheo.lol                  
/* -------------------------------------------------------------
/*  Dumped With     : RbxDumperV2                               
/*  Roblox Version  : version-8884371d30284041
/*  Dumper Version  : 2.1.7
/*  Dumped At       : 21:03 16/06/2026 (GMT)
/*  Total Offsets   : 390
/* =============================================================
*/

#include <cstdint>
#include <string>
namespace Offsets {
    inline std::string ClientVersion = "version-8884371d30284041";

    namespace AnimationTrack {
         inline constexpr uintptr_t Animation = 0xd0;
         inline constexpr uintptr_t Animator = 0x118;
         inline constexpr uintptr_t IsPlaying = 0xa10;
         inline constexpr uintptr_t Looped = 0xf5;
         inline constexpr uintptr_t Speed = 0xe4;
         inline constexpr uintptr_t TimePosition = 0xe8;
    }

    namespace BasePart {
         inline constexpr uintptr_t CastShadow = 0xf5;
         inline constexpr uintptr_t Color3 = 0x194;
         inline constexpr uintptr_t Locked = 0xf6;
         inline constexpr uintptr_t Massless = 0xf7;
         inline constexpr uintptr_t Primitive = 0x148;
         inline constexpr uintptr_t Reflectance = 0xec;
         inline constexpr uintptr_t Shape = 0x1b1;
         inline constexpr uintptr_t Transparency = 0xf0;
    }

    namespace ByteCode {
         inline constexpr uintptr_t Pointer = 0x10;
         inline constexpr uintptr_t Size = 0x20;
    }

    namespace Camera {
         inline constexpr uintptr_t CameraSubject = 0xe8;
         inline constexpr uintptr_t CameraType = 0x158;
         inline constexpr uintptr_t FieldOfView = 0x160;
         inline constexpr uintptr_t Position = 0x11c;
         inline constexpr uintptr_t Rotation = 0xf8;
         inline constexpr uintptr_t Viewport = 0x2ac;
         inline constexpr uintptr_t ViewportSize = 0x2e8;
    }

    namespace ClickDetector {
         inline constexpr uintptr_t MaxActivationDistance = 0x100;
         inline constexpr uintptr_t MouseIcon = 0xe0;
    }

    namespace DataModel {
         inline constexpr uintptr_t CreatorId = 0x198;
         inline constexpr uintptr_t GameId = 0x1a0;
         inline constexpr uintptr_t GameLoaded = 0x678;
         inline constexpr uintptr_t JobId = 0x138;
         inline constexpr uintptr_t PlaceId = 0x1a8;
         inline constexpr uintptr_t PlaceVersion = 0x1c4;
         inline constexpr uintptr_t PrimitiveCount = 0x4a8;
         inline constexpr uintptr_t ScriptContext = 0x440;
         inline constexpr uintptr_t ServerIP = 0x660;
         inline constexpr uintptr_t ToRenderView1 = 0x1e0;
         inline constexpr uintptr_t ToRenderView2 = 0x8;
         inline constexpr uintptr_t ToRenderView3 = 0x28;
         inline constexpr uintptr_t Workspace = 0x178;
    }

    namespace FakeDataModel {
         inline constexpr uintptr_t Pointer = 0x7bcf6a8;
         inline constexpr uintptr_t RealDataModel = 0x1d8;
    }

    namespace GuiObject {
         inline constexpr uintptr_t BackgroundColor3 = 0x540;
         inline constexpr uintptr_t BorderColor3 = 0x54c;
         inline constexpr uintptr_t Image = 0x988;
         inline constexpr uintptr_t LayoutOrder = 0x580;
         inline constexpr uintptr_t Position = 0x510;
         inline constexpr uintptr_t RichText = 0xb50;
         inline constexpr uintptr_t Rotation = 0x188;
         inline constexpr uintptr_t ScreenGui_Enabled = 0x4c4;
         inline constexpr uintptr_t Size = 0x530;
         inline constexpr uintptr_t Text = 0xda0;
         inline constexpr uintptr_t TextColor3 = 0xe50;
         inline constexpr uintptr_t Visible = 0x5ad;
    }

    namespace Humanoid {
         inline constexpr uintptr_t AutoRotate = 0x1e1;
         inline constexpr uintptr_t FloorMaterial = 0x190;
         inline constexpr uintptr_t Health = 0x194;
         inline constexpr uintptr_t HipHeight = 0x1a0;
         inline constexpr uintptr_t HumanoidState = 0x8a0;
         inline constexpr uintptr_t HumanoidStateID = 0x20;
         inline constexpr uintptr_t Jump = 0x1e6;
         inline constexpr uintptr_t JumpHeight = 0x1ac;
         inline constexpr uintptr_t JumpPower = 0x1b0;
         inline constexpr uintptr_t MaxHealth = 0x1b4;
         inline constexpr uintptr_t MaxSlopeAngle = 0x1b8;
         inline constexpr uintptr_t MoveDirection = 0x158;
         inline constexpr uintptr_t RigType = 0x1cc;
         inline constexpr uintptr_t Walkspeed = 0x1dc;
         inline constexpr uintptr_t WalkspeedCheck = 0x3c4;
    }

    namespace Instance {
         inline constexpr uintptr_t AttributeContainer = 0x48;
         inline constexpr uintptr_t AttributeList = 0x18;
         inline constexpr uintptr_t AttributeToNext = 0x58;
         inline constexpr uintptr_t AttributeToValue = 0x18;
         inline constexpr uintptr_t ChildrenEnd = 0x8;
         inline constexpr uintptr_t ChildrenStart = 0x78;
         inline constexpr uintptr_t ClassBase = 0xcc0;
         inline constexpr uintptr_t ClassDescriptor = 0x18;
         inline constexpr uintptr_t ClassName = 0x8;
         inline constexpr uintptr_t Name = 0xb0;
         inline constexpr uintptr_t Parent = 0x70;
    }

    namespace Lighting {
         inline constexpr uintptr_t Ambient = 0xe0;
         inline constexpr uintptr_t Brightness = 0x128;
         inline constexpr uintptr_t ClockTime = 0x1c0;
         inline constexpr uintptr_t ColorShift_Bottom = 0xf8;
         inline constexpr uintptr_t ColorShift_Top = 0xec;
         inline constexpr uintptr_t ExposureCompensation = 0x134;
         inline constexpr uintptr_t FogColor = 0x104;
         inline constexpr uintptr_t FogEnd = 0x13c;
         inline constexpr uintptr_t FogStart = 0x140;
         inline constexpr uintptr_t GeographicLatitude = 0x198;
         inline constexpr uintptr_t OutdoorAmbient = 0x110;
    }

    namespace LocalScript {
         inline constexpr uintptr_t ByteCode = 0x1a8;
    }

    namespace MeshPart {
         inline constexpr uintptr_t MeshId = 0x2f8;
         inline constexpr uintptr_t Texture = 0x328;
    }

    namespace Misc {
         inline constexpr uintptr_t Adornee = 0x108;
         inline constexpr uintptr_t AnimationId = 0xd8;
         inline constexpr uintptr_t StringLength = 0x10;
         inline constexpr uintptr_t Value = 0xd0;
    }

    namespace Model {
         inline constexpr uintptr_t PrimaryPart = 0x278;
         inline constexpr uintptr_t Scale = 0x164;
    }

    namespace ModuleScript {
         inline constexpr uintptr_t ByteCode = 0x150;
    }

    namespace MouseService {
         inline constexpr uintptr_t InputObject = 0x108;
         inline constexpr uintptr_t MousePosition = 0xec;
         inline constexpr uintptr_t SensitivityPointer = 0x307;
    }

    namespace Player {
         inline constexpr uintptr_t CameraMode = 0x35c;
         inline constexpr uintptr_t DisplayName = 0x150;
         inline constexpr uintptr_t LocalPlayer = 0x148;
         inline constexpr uintptr_t MaxZoomDistance = 0x354;
         inline constexpr uintptr_t MinZoomDistance = 0x358;
         inline constexpr uintptr_t ModelInstance = 0x3d0;
         inline constexpr uintptr_t Mouse = 0x1188;
         inline constexpr uintptr_t Team = 0x2d0;
         inline constexpr uintptr_t UserId = 0x2f8;
    }

    namespace PlayerMouse {
         inline constexpr uintptr_t Icon = 0xe0;
         inline constexpr uintptr_t Workspace = 0x168;
    }

    namespace Primitive {
         inline constexpr uintptr_t AssemblyAngularVelocity = 0x104;
         inline constexpr uintptr_t AssemblyLinearVelocity = 0xf8;
         inline constexpr uintptr_t Flags = 0x1b6;
         inline constexpr uintptr_t Material = 0x0;
         inline constexpr uintptr_t Owner = 0x208;
         inline constexpr uintptr_t Position = 0xec;
         inline constexpr uintptr_t Rotation = 0xc8;
         inline constexpr uintptr_t Size = 0x1b8;
         inline constexpr uintptr_t Validate = 0x6;
    }

    namespace PrimitiveFlags {
         inline constexpr uintptr_t Anchored = 0x2;
         inline constexpr uintptr_t CanCollide = 0x8;
         inline constexpr uintptr_t CanQuery = 0x20;
         inline constexpr uintptr_t CanTouch = 0x10;
    }

    namespace ProximityPrompt {
         inline constexpr uintptr_t ActionText = 0xc8;
         inline constexpr uintptr_t Enabled = 0x14e;
         inline constexpr uintptr_t GamepadKeyCode = 0x134;
         inline constexpr uintptr_t HoldDuration = 0x138;
         inline constexpr uintptr_t KeyCode = 0x13c;
         inline constexpr uintptr_t MaxActivationDistance = 0x140;
         inline constexpr uintptr_t ObjectText = 0xe8;
         inline constexpr uintptr_t RequiresLineOfSight = 0x14f;
    }

    namespace RenderJob {
         inline constexpr uintptr_t FakeDataModel = 0x38;
         inline constexpr uintptr_t RealDataModel = 0x1c8;
         inline constexpr uintptr_t RenderView = 0x1d0;
    }

    namespace RenderView {
         inline constexpr uintptr_t DeviceD3D11 = 0x8;
         inline constexpr uintptr_t VisualEngine = 0x10;
    }

    namespace RunService {
         inline constexpr uintptr_t HeartbeatFPS = 0xb8;
         inline constexpr uintptr_t HeartbeatTask = 0xf8;
    }

    namespace Sky {
         inline constexpr uintptr_t MoonAngularSize = 0x25c;
         inline constexpr uintptr_t MoonTextureId = 0xe0;
         inline constexpr uintptr_t SkyboxBk = 0x110;
         inline constexpr uintptr_t SkyboxDn = 0x140;
         inline constexpr uintptr_t SkyboxFt = 0x170;
         inline constexpr uintptr_t SkyboxLf = 0x1a0;
         inline constexpr uintptr_t SkyboxOrientation = 0x250;
         inline constexpr uintptr_t SkyboxRt = 0x1d0;
         inline constexpr uintptr_t SkyboxUp = 0x200;
         inline constexpr uintptr_t StarCount = 0x260;
         inline constexpr uintptr_t SunAngularSize = 0x254;
         inline constexpr uintptr_t SunTextureId = 0x230;
    }

    namespace SpecialMesh {
         inline constexpr uintptr_t MeshId = 0x110;
         inline constexpr uintptr_t Scale = 0xdc;
    }

    namespace StatsItem {
         inline constexpr uintptr_t Value = 0xc8;
    }

    namespace TaskScheduler {
         inline constexpr uintptr_t JobEnd = 0xd0;
         inline constexpr uintptr_t JobName = 0x18;
         inline constexpr uintptr_t JobStart = 0xc8;
         inline constexpr uintptr_t MaxFPS = 0xb0;
         inline constexpr uintptr_t Pointer = 0x815c668;
    }

    namespace Team {
         inline constexpr uintptr_t BrickColor = 0xd0;
    }

    namespace Textures {
         inline constexpr uintptr_t Decal_Texture = 0x198;
         inline constexpr uintptr_t Texture_Texture = 0x198;
    }

    namespace VisualEngine {
         inline constexpr uintptr_t Dimensions = 0xab0;
         inline constexpr uintptr_t Pointer = 0x82ea3f8;
         inline constexpr uintptr_t ViewMatrix = 0x150;
    }

    namespace Workspace {
         inline constexpr uintptr_t CurrentCamera = 0x4a8;
         inline constexpr uintptr_t DistributedGameTime = 0x4c8;
         inline constexpr uintptr_t Gravity = 0x210;
         inline constexpr uintptr_t ReadOnlyGravity = 0x9e8;
         inline constexpr uintptr_t World = 0x400;
    }

}
